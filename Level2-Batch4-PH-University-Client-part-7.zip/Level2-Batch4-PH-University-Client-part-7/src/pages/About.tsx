const About = () => {
  return (
    <div>
      <h1> This is About component </h1>
    </div>
  );
};

export default About;
