const AdminDashboard = () => {
  return (
    <div>
      <h1> This is AdminDashboard component </h1>
    </div>
  );
};

export default AdminDashboard;
