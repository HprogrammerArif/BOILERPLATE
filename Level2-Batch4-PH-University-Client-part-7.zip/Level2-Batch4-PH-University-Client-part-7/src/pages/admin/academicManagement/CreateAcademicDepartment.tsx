const CreateAcademicDepartment = () => {
  return (
    <div>
      <h1> This is CreateAcademicDepartment component </h1>
    </div>
  );
};

export default CreateAcademicDepartment;
