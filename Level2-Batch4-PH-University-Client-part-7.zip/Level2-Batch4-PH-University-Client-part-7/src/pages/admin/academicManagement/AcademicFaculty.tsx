const AcademicFaculty = () => {
  return (
    <div>
      <h1> This is AcademicFaculty component </h1>
    </div>
  );
};

export default AcademicFaculty;
