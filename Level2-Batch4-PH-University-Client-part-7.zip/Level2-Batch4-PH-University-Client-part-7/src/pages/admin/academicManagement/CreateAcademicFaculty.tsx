const CreateAcademicFaculty = () => {
  return (
    <div>
      <h1> This is CreateAcademicFaculty component </h1>
    </div>
  );
};

export default CreateAcademicFaculty;
