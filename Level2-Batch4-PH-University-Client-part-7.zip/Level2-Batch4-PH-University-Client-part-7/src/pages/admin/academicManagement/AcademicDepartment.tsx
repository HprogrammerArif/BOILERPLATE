const AcademicDepartment = () => {
  return (
    <div>
      <h1> This is AcademicDepartment component </h1>
    </div>
  );
};

export default AcademicDepartment;
