const OfferedCourses = () => {
  return (
    <div>
      <h1> This is OfferedCourses component </h1>
    </div>
  );
};

export default OfferedCourses;
