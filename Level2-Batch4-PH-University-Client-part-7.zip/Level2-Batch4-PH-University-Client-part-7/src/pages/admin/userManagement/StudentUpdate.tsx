const StudentUpdate = () => {
  return (
    <div>
      <h1> This is StudentUpdate component </h1>
    </div>
  );
};

export default StudentUpdate;
