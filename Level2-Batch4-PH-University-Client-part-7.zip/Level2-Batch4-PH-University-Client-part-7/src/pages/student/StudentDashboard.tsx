const StudentDashboard = () => {
  return (
    <div>
      <h1> This is StudentDashboard component </h1>
    </div>
  );
};

export default StudentDashboard;
