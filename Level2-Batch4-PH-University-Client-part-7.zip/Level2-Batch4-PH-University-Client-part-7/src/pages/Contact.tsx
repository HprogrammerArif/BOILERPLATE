const Contact = () => {
  return (
    <div>
      <h1> This is Contact component </h1>
    </div>
  );
};

export default Contact;
