const FacultyDashboard = () => {
  return (
    <div>
      <h1> This is FacultyDashboard component </h1>
    </div>
  );
};

export default FacultyDashboard;
